# cefet-web-edukids
Um jogo para entreter sobrinhos

Esta atividade foi _deprecated in favor of_ [fegemo/cefet-front-end-edukids](https://github.com/fegemo/cefet-front-end-edukids)
